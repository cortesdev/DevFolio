#!/bin/bash

psql -h 172.18.102.72 -d paxlife_mini_dwh -U elk_svc -w -t -f user_data_per_flight.sql
