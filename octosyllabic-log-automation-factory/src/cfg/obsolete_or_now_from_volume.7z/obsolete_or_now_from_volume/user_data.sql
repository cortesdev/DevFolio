

SELECT jsondata FROM staging.userdata_to_json;

